# 🚀 Быстрое исправление ошибки 413

## Что сделано

✅ Увеличены лимиты загрузки до **500MB**:
- Nginx: `client_max_body_size 500M`
- Express: `express.json({ limit: '500mb' })`
- Multer: уже был 500MB

✅ Добавлены таймауты для больших файлов
✅ Отключен proxy buffering для стриминга

## Применить исправление

### Вариант 1: Автоматически (рекомендуется)

```powershell
.\fix-upload-limit.ps1
```

### Вариант 2: Вручную

1. Подключитесь к серверу:
```bash
ssh root@mukammalotaona.uz
```

2. Загрузите и запустите скрипт:
```bash
# Скопируйте fix-upload-limit.sh на сервер
chmod +x fix-upload-limit.sh
./fix-upload-limit.sh
```

3. Обновите код приложения:
```bash
cd /var/www/moo
git pull
npm run build
pm2 restart moo
```

## Проверка

После применения попробуйте загрузить видео в админ панели.

## Подробная документация

См. `doc/FIX_413_ERROR.md` для детальной информации.
