# 🎥 Исправление проблемы загрузки видео (408 Timeout на 13-14%)

## 🔴 Найденные проблемы

### 1. **КРИТИЧЕСКАЯ: Content-Type установлен вручную**
```typescript
// ❌ БЫЛО (src/api/index.ts)
headers: { 
  'Content-Type': 'multipart/form-data',
}
```

**Проблема:** Когда вы вручную устанавливаете `Content-Type: multipart/form-data`, браузер/axios НЕ добавляет `boundary` параметр. Без boundary сервер не может распарсить multipart данные, и multer не видит файл.

**Решение:** Удалить эту строку. Axios автоматически установит правильный header с boundary.

```typescript
// ✅ СТАЛО
// Axios автоматически установит: 
// Content-Type: multipart/form-data; boundary=----WebKitFormBoundary...
```

---

### 2. **Multer limits слишком малы**
```typescript
// ❌ БЫЛО (server/routes/upload.ts)
limits: {
  fileSize: 500 * 1024 * 1024, // 500MB
}
```

**Проблема:** Вы хотите загружать до 2GB, но multer обрезает на 500MB.

**Решение:**
```typescript
// ✅ СТАЛО
limits: {
  fileSize: 2 * 1024 * 1024 * 1024, // 2GB
  fieldSize: 2 * 1024 * 1024 * 1024,
}
```

---

### 3. **Нет диагностики разрывов**

**Проблема:** Невозможно понять, почему обрывается соединение.

**Решение:** Добавлено логирование:
- `req.on('aborted')` - клиент отменил
- `req.on('close')` - соединение закрыто
- `res.on('finish')` - ответ отправлен
- Прогресс каждые 5 секунд

---

### 4. **Нет обработки ошибок 408/413/502**

**Проблема:** Пользователь видит только "Upload error".

**Решение:** Добавлена детальная обработка:
- 408 - Timeout
- 413 - File too large
- 499 - Client closed request
- 502/504 - Gateway error
- Network Error

---

## ✅ Внесённые изменения

### Frontend (`src/api/index.ts`)
1. ❌ **Удалён** `Content-Type: 'multipart/form-data'` header
2. ✅ Добавлен комментарий о том, почему не нужно ставить вручную
3. ✅ Увеличен лимит до 2GB в UI

### Frontend (`src/pages/admin/AdminDarslar.tsx`)
1. ✅ Увеличен лимит проверки до 2GB
2. ✅ Добавлена детальная обработка ошибок (408, 413, 499, 502, 504, Network)
3. ✅ Улучшены сообщения об ошибках на узбекском языке

### Backend (`server/routes/upload.ts`)
1. ✅ Увеличен multer limit до 2GB
2. ✅ Добавлено логирование:
   - Upload progress каждые 5 секунд
   - Connection events (aborted, close)
   - Success/failure с деталями
3. ✅ Добавлен error handler для multer ошибок
4. ✅ Детальные логи для диагностики

### Backend (`server/index.ts`)
- ✅ Уже настроено: timeouts 30 минут, limits 500MB в express.json/urlencoded
- ✅ Уже настроено: server.setTimeout, headersTimeout, requestTimeout

### Nginx (`nginx-moo-final.conf`)
- ✅ Уже настроено: client_max_body_size 2000M
- ✅ Уже настроено: timeouts 1800s (30 минут)
- ✅ Уже настроено: proxy_request_buffering off

---

## 🧪 Тестирование

### Ручной тест-чек-лист

#### 1. Малый файл (< 50MB)
- [ ] Загрузить видео 20-30MB
- [ ] Проверить прогресс-бар
- [ ] Проверить успешное сохранение
- [ ] Проверить воспроизведение

#### 2. Средний файл (100-300MB)
- [ ] Загрузить видео 200-300MB
- [ ] Проверить прогресс не останавливается на 13-14%
- [ ] Проверить логи сервера (каждые 5 сек)
- [ ] Проверить успешное завершение

#### 3. Большой файл (500MB-1GB)
- [ ] Загрузить видео 500MB-1GB
- [ ] Проверить стабильность загрузки
- [ ] Проверить скорость (MB/s в UI)
- [ ] Проверить логи сервера

#### 4. Очень большой файл (1-2GB)
- [ ] Загрузить видео 1.5-2GB
- [ ] Проверить что не обрывается
- [ ] Проверить память сервера (не должна расти)
- [ ] Проверить успешное сохранение

#### 5. Медленный интернет (throttling)
- [ ] Chrome DevTools → Network → Slow 3G
- [ ] Загрузить 100MB видео
- [ ] Проверить что не timeout
- [ ] Проверить прогресс-бар

#### 6. Обрыв соединения
- [ ] Начать загрузку
- [ ] Закрыть вкладку на 50%
- [ ] Проверить логи сервера (должно быть "ABORTED")
- [ ] Проверить что файл не остался в uploads/

#### 7. Ошибки
- [ ] Попробовать загрузить файл > 2GB (должна быть ошибка 413)
- [ ] Попробовать загрузить не-видео файл (должна быть ошибка)
- [ ] Проверить сообщения об ошибках на узбекском

---

## 📊 Мониторинг логов

### На сервере (SSH)
```bash
# Смотреть логи в реальном времени
pm2 logs moo --lines 100

# Фильтровать только upload логи
pm2 logs moo | grep -E "Upload|📤|❌|✅"
```

### Что искать в логах:

#### ✅ Успешная загрузка:
```
📤 Upload progress: 50.23MB received (2.15MB/s)
📤 Upload progress: 100.45MB received (2.18MB/s)
📤 Upload progress: 150.67MB received (2.12MB/s)
✅ File uploaded successfully: { filename: 'abc123.mp4', size: '275.93MB', mimetype: 'video/mp4' }
✅ Upload completed successfully. Duration: 127.5 seconds
```

#### ❌ Обрыв на 13-14%:
```
📤 Upload progress: 37.14MB received (1.85MB/s)
❌ Connection CLOSED before response sent. Duration: 20.3 seconds
```

#### ❌ Клиент отменил:
```
📤 Upload progress: 50.00MB received (2.00MB/s)
❌ Upload ABORTED by client after 25.0 seconds
```

---

## 🔧 Если проблема осталась

### 1. Проверить Cloudflare (если используется)
Cloudflare может иметь свои лимиты:
- Free plan: 100MB max upload
- Pro plan: 500MB max upload
- Business+: настраивается

**Решение:** Отключить Cloudflare для `/api/upload/*` или апгрейд план.

### 2. Проверить VPS ресурсы
```bash
# Проверить RAM
free -h

# Проверить disk space
df -h

# Проверить CPU
top
```

### 3. Проверить Nginx логи
```bash
# Error log
tail -f /var/log/nginx/error.log

# Access log
tail -f /var/log/nginx/access.log | grep upload
```

### 4. Увеличить Nginx timeouts (если нужно)
```nginx
# В nginx-moo-final.conf, секция location /api/
proxy_read_timeout 3600s;      # 1 час вместо 30 минут
proxy_send_timeout 3600s;
client_body_timeout 3600s;
```

---

## 📝 Итог

### Главная причина 408 на 13-14%:
**Content-Type установлен вручную без boundary** → multer не видит файл → соединение висит → nginx timeout.

### Исправлено:
1. ✅ Удалён ручной Content-Type
2. ✅ Увеличен multer limit до 2GB
3. ✅ Добавлено логирование для диагностики
4. ✅ Добавлена обработка ошибок
5. ✅ Улучшен UX (понятные сообщения)

### Следующие шаги:
1. Пересобрать фронтенд: `npm run build`
2. Перезапустить бэкенд: `pm2 restart moo`
3. Протестировать загрузку 300MB видео
4. Проверить логи сервера
5. Если работает - протестировать 1GB+

---

## 🚀 Деплой изменений

```bash
# На локальной машине
npm run build

# Загрузить на сервер (используйте ваш скрипт)
# Например: ./deploy-vps.sh или ./deploy-164.sh

# На сервере
pm2 restart moo
pm2 logs moo --lines 50
```

---

**Дата исправления:** 2026-01-19  
**Статус:** ✅ Готово к тестированию
