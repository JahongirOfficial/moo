# 🚀 Инструкция по исправлению проблемы с кешированием

## Сервер: 164.68.109.208
## Проект: /var/www/mo

---

## 📋 Шаг 1: Проверить текущую конфигурацию

```bash
# Подключиться к серверу
ssh root@164.68.109.208

# Перейти в папку проекта
cd /var/www/mo

# Запустить проверку
bash check-nginx-config.sh
```

Это покажет:
- Текущую конфигурацию Nginx
- Какие файлы есть в dist/assets
- Что ссылается в index.html
- Результаты curl тестов

---

## 🔧 Шаг 2: Применить исправление

### Автоматически (рекомендуется):

```bash
cd /var/www/mo
bash fix-nginx-cache.sh
```

### Вручную:

```bash
# 1. Скопировать конфигурацию
sudo cp nginx-fix.conf /etc/nginx/sites-available/mo
sudo ln -sf /etc/nginx/sites-available/mo /etc/nginx/sites-enabled/mo

# 2. Проверить
sudo nginx -t

# 3. Применить
sudo systemctl reload nginx

# 4. Очистить кеш
sudo rm -rf /var/cache/nginx/*
```

---

## 🌐 Шаг 3: Проверить в браузере

1. **Очистить кеш браузера:**
   - `Ctrl + Shift + Delete` → Очистить кеш
   - Или `Ctrl + Shift + R` (жесткая перезагрузка)
   - Или открыть в режиме инкогнито

2. **Открыть сайт:**
   ```
   http://164.68.109.208
   ```

3. **Проверить в DevTools:**
   - Открыть DevTools (F12)
   - Вкладка Network
   - Обновить страницу
   - Проверить, что все `.js` файлы загружаются с `Status: 200`
   - Проверить, что `Content-Type: application/javascript`

---

## ✅ Проверка результата

### На сервере:

```bash
# 1. index.html не должен кешироваться
curl -I http://164.68.109.208/index.html | grep Cache-Control
# Ожидается: Cache-Control: no-store, no-cache

# 2. Несуществующий asset должен возвращать 404
curl -I http://164.68.109.208/assets/fake.js
# Ожидается: HTTP/1.1 404 Not Found

# 3. Существующий asset должен кешироваться
curl -I http://164.68.109.208/assets/index-*.js | grep Cache-Control
# Ожидается: Cache-Control: public, immutable
```

---

## 🔄 Для будущих деплоев

После каждого `npm run build`:

```bash
# 1. Собрать проект локально
npm run build

# 2. Загрузить на сервер (используйте ваш метод)
scp -r dist/* root@164.68.109.208:/var/www/mo/dist/

# 3. Перезапустить PM2 (если нужно)
ssh root@164.68.109.208 "pm2 restart mo"

# 4. Очистить кеш браузера
```

Или используйте обновленный deploy скрипт:
```bash
bash deploy-164.sh
```

---

## 🆘 Если проблема осталась

1. **Проверить логи Nginx:**
   ```bash
   sudo tail -f /var/log/nginx/error.log
   sudo tail -f /var/log/nginx/access.log
   ```

2. **Проверить, что файлы существуют:**
   ```bash
   ls -la /var/www/mo/dist/assets/
   ```

3. **Проверить права доступа:**
   ```bash
   sudo chown -R www-data:www-data /var/www/mo/dist
   sudo chmod -R 755 /var/www/mo/dist
   ```

4. **Полностью перезапустить Nginx:**
   ```bash
   sudo systemctl restart nginx
   ```

---

## 📞 Контакты для помощи

Если проблема не решается, предоставьте:
1. Вывод `bash check-nginx-config.sh`
2. Скриншот ошибки в браузере (DevTools → Console)
3. Скриншот Network вкладки (DevTools → Network)
