#!/bin/bash

echo "🔍 Диагностика проблемы загрузки видео на продакшене"
echo "======================================================"
echo ""

# 1. Проверка nginx конфигурации
echo "1️⃣ Проверка nginx конфигурации:"
echo "--------------------------------"
sudo nginx -T 2>/dev/null | grep -A 5 "client_max_body_size"
echo ""

# 2. Проверка папки uploads
echo "2️⃣ Проверка папки uploads:"
echo "--------------------------"
if [ -d "/var/www/moo/uploads" ]; then
    echo "✅ Папка существует"
    ls -lah /var/www/moo/uploads | head -10
    echo ""
    echo "Права доступа:"
    ls -ld /var/www/moo/uploads
    echo ""
    echo "Владелец процесса Node.js:"
    ps aux | grep "node.*3001" | grep -v grep
else
    echo "❌ Папка /var/www/moo/uploads не найдена!"
fi
echo ""

# 3. Проверка логов nginx
echo "3️⃣ Последние ошибки nginx:"
echo "--------------------------"
sudo tail -20 /var/log/nginx/error.log
echo ""

# 4. Проверка логов приложения
echo "4️⃣ Логи приложения (PM2):"
echo "-------------------------"
pm2 logs moo --lines 30 --nostream
echo ""

# 5. Проверка SSL сертификата
echo "5️⃣ Проверка SSL:"
echo "----------------"
echo | openssl s_client -connect mukammalotaona.uz:443 -servername mukammalotaona.uz 2>/dev/null | grep -E "subject=|issuer=|Verify return code"
echo ""

# 6. Тест загрузки через curl
echo "6️⃣ Тест API endpoint:"
echo "---------------------"
TOKEN="YOUR_ADMIN_TOKEN_HERE"
echo "Попробуйте загрузить тестовый файл:"
echo "curl -X POST https://mukammalotaona.uz/api/upload/video \\"
echo "  -H 'Authorization: Bearer \$TOKEN' \\"
echo "  -F 'video=@test.mp4'"
echo ""

# 7. Проверка дискового пространства
echo "7️⃣ Дисковое пространство:"
echo "-------------------------"
df -h /var/www/moo
echo ""

# 8. Проверка процесса Node.js
echo "8️⃣ Статус Node.js процесса:"
echo "---------------------------"
pm2 status
echo ""

echo "======================================================"
echo "✅ Диагностика завершена"
echo ""
echo "📋 Что проверить:"
echo "   1. client_max_body_size должен быть 500M"
echo "   2. Папка uploads должна существовать с правами 755"
echo "   3. В логах не должно быть ошибок 413 или 502"
echo "   4. SSL сертификат должен быть валидным"
echo "   5. Должно быть достаточно места на диске"
echo ""
