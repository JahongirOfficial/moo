# 🚀 БЫСТРОЕ ИСПРАВЛЕНИЕ 408 TIMEOUT ПРИ ЗАГРУЗКЕ ВИДЕО

## ❌ Проблема
Загрузка видео обрывается на 13-14% (37MB из 276MB) с ошибкой **408 Request Timeout**.

## ✅ Причина
**Content-Type установлен вручную без boundary** в axios запросе → multer не может распарсить multipart → соединение висит → nginx timeout.

## 🔧 Исправления (уже внесены)

### 1. Frontend: `src/api/index.ts`
```typescript
// ❌ УДАЛЕНО:
headers: { 'Content-Type': 'multipart/form-data' }

// ✅ Axios сам установит правильный header с boundary
```

### 2. Backend: `server/routes/upload.ts`
- ✅ Увеличен limit: 500MB → 2GB
- ✅ Добавлено логирование прогресса
- ✅ Добавлена обработка ошибок

### 3. Frontend: `src/pages/admin/AdminDarslar.tsx`
- ✅ Увеличен лимит: 500MB → 2GB
- ✅ Добавлена обработка ошибок 408/413/502

## 📦 Деплой

### Windows (локальная машина):
```powershell
# 1. Собрать фронтенд
npm run build

# 2. Загрузить на сервер (выберите один из скриптов)
.\deploy-vps.ps1
# или
.\deploy-164.ps1
# или
.\deploy-local-to-164.ps1
```

### Linux/Mac (локальная машина):
```bash
# 1. Собрать фронтенд
npm run build

# 2. Загрузить на сервер
./deploy-vps.sh
# или
./deploy-164.sh
```

### На сервере (SSH):
```bash
# Перезапустить приложение
pm2 restart moo

# Смотреть логи
pm2 logs moo --lines 100

# Фильтровать upload логи
pm2 logs moo | grep -E "Upload|📤|❌|✅"
```

## 🧪 Тест

1. Открыть админ-панель: https://mukammalotaona.uz/admin/darslar
2. Нажать "Qo'shish" → выбрать тип "Video"
3. Загрузить видео 200-300MB
4. **Ожидаемый результат:** загрузка проходит до 100% без обрыва

### Что смотреть в логах:
```
✅ Успешно:
📤 Upload progress: 50.23MB received (2.15MB/s)
📤 Upload progress: 100.45MB received (2.18MB/s)
✅ File uploaded successfully: { filename: 'abc123.mp4', size: '275.93MB' }
✅ Upload completed successfully. Duration: 127.5 seconds

❌ Если обрыв:
📤 Upload progress: 37.14MB received (1.85MB/s)
❌ Connection CLOSED before response sent. Duration: 20.3 seconds
```

## 📋 Чек-лист

- [ ] Код изменён (уже сделано)
- [ ] `npm run build` выполнен
- [ ] Файлы загружены на сервер
- [ ] `pm2 restart moo` выполнен
- [ ] Тест загрузки 200-300MB видео
- [ ] Проверка логов сервера
- [ ] Тест загрузки 1GB видео (опционально)

## 🆘 Если не помогло

1. **Проверить Cloudflare:**
   - Free plan ограничивает upload до 100MB
   - Нужно отключить для `/api/upload/*` или апгрейд

2. **Проверить логи Nginx:**
   ```bash
   tail -f /var/log/nginx/error.log
   ```

3. **Увеличить Nginx timeout (если нужно):**
   ```nginx
   # В nginx-moo-final.conf
   proxy_read_timeout 3600s;  # 1 час
   ```

4. **Проверить ресурсы VPS:**
   ```bash
   free -h    # RAM
   df -h      # Disk
   top        # CPU
   ```

## 📚 Подробная документация
См. `doc/VIDEO_UPLOAD_FIX.md`

---

**Статус:** ✅ Готово к деплою  
**Дата:** 2026-01-19
